package com.training.boothibernate.exceptions;

public class CustomerException extends RuntimeException{
	public CustomerException(String message) {
		super(message);
	}
}


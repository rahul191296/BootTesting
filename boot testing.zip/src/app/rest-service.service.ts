import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient} from '@angular/common/http';

import {map} from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Customer } from './Customer.model';

//Rest endpoint
const endpoint='http://localhost:8585/boot-hibernate/api/customers';

//Http Header Variable
const httpOptions={
    headers: new HttpHeaders({
        'Content-Type' : 'application/json'
    })
};


@Injectable({
  providedIn: 'root'
})
export class RestServiceService {

  constructor(private http: HttpClient) { }

  //method to extract the json data to an angular object
  //will be used as callback by map 
  private extractData(res : Response){
    let contents=res;
    //check if contents are not null
    return contents || { };
  }

  // 5 methods for 5 rest service (CRUD)
  //if Customer modal Customer[]~any

  //method for getting list of customers
   // getCustomers(): Observable<Customer[]>{
   getCustomers(): Observable<any>{
     return this.http.get(endpoint).pipe(map(this.extractData));
  }

  //if Customer modal Customer~any
  getCustomer(id):Observable<any>{
    return this.http.get(endpoint + "/" + id).pipe(map(this.extractData));
  }

  //add a new customer
  addCustomer(customer):Observable<any>{
    //this.http.post(<endpoint>,<message body>,<http header>);
    //need to convert angular object to json data
    return this.http.post(endpoint,JSON.stringify(customer),httpOptions).pipe(map(this.extractData))
  }

  updateCustomer(customer):Observable<any>{
    return this.http.put(endpoint,JSON.stringify(customer),httpOptions).pipe(map(this.extractData));
  }

  deleteCustomer(id):Observable<any>{
    return this.http.delete(endpoint + "/" + id).pipe(map(this.extractData));
  }

}

export class Customer{
    
}